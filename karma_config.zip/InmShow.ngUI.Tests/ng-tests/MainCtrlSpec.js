﻿/// <reference path="g:\inmerge\show\inmshow.ngui.tests\_references.js" />

describe('app controllers', function () {

    beforeEach(module('inmShowApp'));


    describe('ClientCtrl', function () {

        var scope;
        it('should have scope defined', inject(function ($rootScope, $controller) {
            scope = $rootScope.$new();
            // this is the line that caused me pain
            $controller('ClientCtrl', { $scope: scope });
            expect(scope).toBeDefined();
        }));
    });
});